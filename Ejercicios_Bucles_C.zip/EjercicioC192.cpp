#include <iostream>
using namespace std;
int main() {
    // EjercicioC192: Imprimir numeros del 1 al 10
    for (int i = 1; i <= 10; ++i) cout << i << " ";
    cout << endl;
    return 0;
}
