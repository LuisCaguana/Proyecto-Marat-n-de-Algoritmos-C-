#include <iostream>
using namespace std;
int main() {
    // EjercicioC173: Imprimir numeros del 10 al 1
    for (int i = 10; i >= 1; --i) cout << i << " ";
    cout << endl;
    return 0;
}
